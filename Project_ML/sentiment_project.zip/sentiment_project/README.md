# Product Review Sentiment Analysis — run in VS Code

## Run (one server serves both website and API)
1. Open this folder in VS Code (File > Open Folder).
2. Open a terminal (Ctrl+`) and run:
   - Windows: `run.bat`        - Mac/Linux: `./run.sh`
   (or manually: `cd backend`, `python -m venv ../venv`, activate it, `pip install -r requirements.txt`, `uvicorn server:app --port 8000`)
3. Open http://localhost:8000
First run downloads PyTorch + the model, so it takes a few minutes and needs internet.

## Using YOUR fine-tuned BERT
Without a trained model the server loads a public stand-in and the website shows an amber "STAND-IN MODEL" badge.
To use your own: run `python train_bert.py --csv amazon_review.csv` inside `backend/` (GPU / Colab recommended).
It creates `backend/bert_sentiment_model/`; restart the server and the badge turns green "FINE-TUNED BERT LOADED".

## Where BERT is implemented
- `backend/train_bert.py` — data prep, BERT tokenizer, BERT model + classification head, fine-tuning, evaluation, charts, saving.
- `backend/server.py` — loads the saved model, `/predict` returns label + confidence.
- `frontend/index.html` — website; sends each review (or CSV row) to `/predict`.
