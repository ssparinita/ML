"""
Backend + website in one server.   Run:  uvicorn server:app --port 8000   then open http://localhost:8000
  POST /predict  {"text": "..."} -> {"label": 0|1, "confidence": float}   (0 = Negative, 1 = Positive)
  GET  /health   -> which model is loaded
Model: backend/bert_sentiment_model/ (created by train_bert.py) is used if it exists.
Otherwise a PUBLIC stand-in sentiment model is loaded so the demo still runs -- it is NOT the project's BERT,
and both the terminal and the website badge say so.
"""
from pathlib import Path
import torch
from fastapi import FastAPI
from fastapi.middleware.cors import CORSMiddleware
from fastapi.staticfiles import StaticFiles
from pydantic import BaseModel
from transformers import AutoTokenizer, AutoModelForSequenceClassification

HERE = Path(__file__).parent
OWN = (HERE / "bert_sentiment_model").is_dir()
SRC = str(HERE / "bert_sentiment_model") if OWN else "distilbert-base-uncased-finetuned-sst-2-english"
tokenizer = AutoTokenizer.from_pretrained(SRC)                                # WordPiece tokenizer
model = AutoModelForSequenceClassification.from_pretrained(SRC).eval()        # BERT classifier
print("\n" + ("Loaded your fine-tuned BERT." if OWN else "WARNING: bert_sentiment_model/ not found -> using a public STAND-IN model, not your trained BERT.\n         Run train_bert.py (or copy your saved model folder into backend/) to use the real one.") + "\n")

app = FastAPI()
app.add_middleware(CORSMiddleware, allow_origins=["*"], allow_methods=["*"], allow_headers=["*"])

class Review(BaseModel):
    text: str

@app.get("/health")
def health():
    return {"ok": True, "own_model": OWN, "model": "fine-tuned BERT (this project)" if OWN else "stand-in: public DistilBERT SST-2"}

@app.post("/predict")
def predict(r: Review):
    x = tokenizer(r.text, return_tensors="pt", truncation=True, padding=True, max_length=128)
    with torch.no_grad():
        probs = torch.softmax(model(**x).logits, dim=1)                       # [P(neg), P(pos)]
    label = int(torch.argmax(probs, dim=1))                                   # 0 = Negative, 1 = Positive
    return {"label": label, "confidence": float(probs[0][label])}

app.mount("/", StaticFiles(directory=HERE.parent / "frontend", html=True), name="site")   # serves the website
