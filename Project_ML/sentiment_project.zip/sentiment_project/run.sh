#!/bin/bash
cd "$(dirname "$0")/backend"
[ -d ../venv ] || python3 -m venv ../venv
source ../venv/bin/activate
pip install -r requirements.txt
(sleep 4; (xdg-open http://localhost:8000 || open http://localhost:8000) 2>/dev/null) &
uvicorn server:app --port 8000
